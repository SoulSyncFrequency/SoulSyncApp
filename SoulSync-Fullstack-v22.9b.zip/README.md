# 🌐 SoulSync App

[![codecov](https://codecov.io/gh/SoulSyncFrequency/SoulSyncApp/branch/main/graph/badge.svg)](https://codecov.io/gh/SoulSyncFrequency/SoulSyncApp)
![build](https://img.shields.io/github/actions/workflow/status/SoulSyncFrequency/SoulSyncApp/ci.yml?branch=main)

Fullstack SoulSync aplikacija: terapijski engine, personalizirana prehrana i suplementi, PDF export, CI/CD pipeline i mobilna podrška (Capacitor).

---

## ✨ Glavne značajke
- 🔐 **Auth sistem** (JWT login/register, SQLite by default, opcionalno Postgres).
- 🧠 **Ultra51c terapijski engine** – frequency + molecule terapija, EMDR, psilocybin, DNA reprogramming, Metabolic Awakening.
- 🧬 **SMILES generator** – stvarni molekularni stringovi.
- 📄 **PDF export** – 5-dnevni plan (nutricija + chakre + terapijski moduli).
- 🌗 **Dark/Light mode** + sticky footer.
- 📊 **Testovi & CI/CD**:
  - Backend (Jest, SQLite + Postgres service).
  - Frontend (Vitest, Cypress e2e).
  - Coverage report (Codecov).
  - Docker build & push (ghcr.io).
- 📦 **Capacitor** – spreman za build na Android/iOS.

---

## 🚀 Pokretanje lokalno

### Backend
```bash
cd backend
cp .env.example .env
# Postavi JWT_SECRET
npm i
npm run dev
# http://localhost:5000/api/health
```

### Frontend
```bash
cd frontend
cp .env.example .env
# VITE_API_BASE_URL=http://localhost:5000
npm i
npm run dev
# http://localhost:5173
```

---

## 🧪 Testiranje

### Backend (Jest)
```bash
cd backend
npm run build
npm test -- --coverage
```

### Frontend (Vitest)
```bash
cd frontend
npm run test -- --coverage
```

### Cypress (mocked API)
```bash
cd frontend
npm run dev &
npx cypress open
```

### Cypress (real backend)
```bash
cd backend && npm run dev &
cd frontend && VITE_API_BASE_URL=http://localhost:5000 npm run dev &
npx cypress run --spec cypress/e2e/real_flow.cy.ts
```

---

## ☁️ Deploy

### Render (backend)
- `render.yaml` je spreman.
- Env vars:  
  - `PORT=5000`  
  - `JWT_SECRET=<secret>`  
  - `PG_CONNECTION_STRING=<postgres-url>` (opcionalno)

### Frontend (prod build)
```bash
cd frontend
echo "VITE_API_BASE_URL=https://api.soulsync.app" > .env.production
npm run build
npx cap copy
```

---

## 📱 Play/App Store checklist
Detaljni koraci → [STORE-CHECKLIST.md](./STORE-CHECKLIST.md)

---

## 📜 Licenca
Projekt je objavljen pod [MIT licencom](./LICENSE).  
© 2025 SoulSyncFrequency

## 📦 Analiza bundla (frontend)

Za provjeru veličine i strukture frontenda koristi se **rollup-plugin-visualizer**.

### Kako pokrenuti
```bash
cd frontend
npm run build
```

Nakon builda generira se fajl:
```
frontend/dist/stats.html
```

### Pregled
- Otvori `stats.html` u browseru.  
- Dobit ćeš grafički prikaz svih paketa u bundlu (React, tvoje komponente, third-party libraryji).  
- To pomaže da vidiš što zauzima najviše prostora i gdje se može optimizirati.
