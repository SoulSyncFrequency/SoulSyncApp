import { expect, test } from 'vitest'
test('basic math', () => { expect(2+2).toBe(4) })
