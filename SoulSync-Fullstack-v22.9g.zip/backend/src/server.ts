import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'

dotenv.config()
const app = express()
app.use(cors())
app.use(express.json())
import authRouter from './auth.js'
app.use('/api/auth', authRouter)
import path from 'path'
import fs from 'fs-extra'
import { generateTherapy } from './engine/therapy.js'
import { generateTherapyPDF } from './engine/pdf.js'

// serve reports statically
app.use('/reports', (req, res, next) => {
  const p = path.join(process.cwd(), 'reports')
  fs.ensureDirSync(p)
  express.static(p)(req, res, next)
})

const PORT = process.env.PORT || 5000

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'soulsync-backend', version: '1.0.0' })
})

// Full therapy endpoint
app.post('/api/generateTherapy', async (req, res) => {
  try {
    const input = req.body || {}
    const plan = generateTherapy({
      disease: input.disease,
      symptoms: input.symptoms,
      language: input.language || 'en'
    })
    const pdf = await generateTherapyPDF(plan, input)
    res.json({ ok: true, therapy: plan, pdfUrl: pdf.urlPath })
  } catch (e) {
    console.error(e)
    res.status(500).json({ ok: false, error: 'THERAPY_GENERATION_FAILED' })
  }
})

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`)
})
