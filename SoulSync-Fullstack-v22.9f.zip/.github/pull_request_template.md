## Opis
Kratko objasni što ovaj PR radi.

## Promjene
- [ ] Nova funkcionalnost
- [ ] Popravak bugova
- [ ] Dokumentacija
- [ ] Testovi

## Testovi
- [ ] Dodani testovi za nove funkcionalnosti
- [ ] Svi postojeći testovi prolaze

## Coverage
Codecov će ovdje automatski komentirati razliku u pokrivenosti testovima.
