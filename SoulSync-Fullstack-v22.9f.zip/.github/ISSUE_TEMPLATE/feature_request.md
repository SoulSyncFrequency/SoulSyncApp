---
name: Feature Request
about: Predloži novu funkcionalnost ili poboljšanje
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## Opis
Opiši jasno novu funkcionalnost ili poboljšanje.

## Rješenje koje predlažeš
Kako bi to trebalo raditi?

## Alternativna rješenja
Jesu li postojale druge ideje?

## Dodatne informacije
Dodaj dodatni kontekst ili primjere ako je potrebno.
