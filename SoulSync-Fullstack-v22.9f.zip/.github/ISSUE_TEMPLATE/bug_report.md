---
name: Bug Report
about: Prijavi problem ili grešku
title: "[BUG] "
labels: bug
assignees: ''
---

## Opis
Jasno opiši bug.

## Koraci za reproducirati
1. Idi na '...'
2. Klikni na '...'
3. Očekivano ponašanje je '...'

## Očekivano ponašanje
Što si očekivao da se dogodi?

## Screenshoti / Logovi
Ako je moguće, dodaj screenshot ili log.

## Okruženje
- OS: [npr. Windows 10, Ubuntu 20.04]
- Browser: [npr. Chrome 120]
- Verzija aplikacije: [npr. v22.9]
